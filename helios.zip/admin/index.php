<?php
session_start();
include("database.php");
if(isset($_REQUEST['submit'])){
	$email=$_REQUEST['email'];
	$password2=$_REQUEST['password'];
	$password=sha1($password2);
	if($obj->login("students","*","email='$email' AND password='$password'")!=false){
		$student=$obj->login("students","*","email='$email' AND password='$password'");
		$_SESSION['name']=$student['name'];
		if(isset($_REQUEST['remember'])){
			setcookie("email",$email,time()+86400);
			setcookie("password",$password2,time()+86400);
		}
		header("location:home.php");
	}
	else{
		$msg="Username/Password Invalid";	
	}
}

if(isset($_SESSION['name'])){
	header("location:home.php");
	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>User Login</title>

</head>

<body style="margin:200px auto; width:500px;">
<?php
echo isset($msg)?$msg:"";
?>
<form action="index.php" method="post">
	Email:<input type="text" value="<?php echo isset($_COOKIE['email'])?$_COOKIE['email']:''?>" name="email" />
	Password<input type="password" name="password" value="<?php echo isset($_COOKIE['password'])?$_COOKIE['password']:''?>" /><br /><br />

Remember me <input type="checkbox" name="remember" value="remember" /><br /><br />
<input type="submit" name="submit" value="Login" />
</form>
</body>
</html>