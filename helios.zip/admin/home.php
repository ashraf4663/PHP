<?php
include("database.php");
session_start();
if(isset($_REQUEST['logout'])){
	session_destroy();
	header("location:index.php");
}
if(!isset($_SESSION['name'])){
	//header("location:index.php");
	die("Invalid Request");
}
if(isset($_REQUEST['add_menu'])){
	extract($_REQUEST);
	
	if($obj->Insert("menus","name='$name',content='$content1',status=$status")){
		//$msg="Insert Success";
		header("location:home.php?action=menu");
	}
	else{
		$msg="Insert Fail";	
	}
}

if(isset($_REQUEST['add_category'])){
	extract($_REQUEST);
	
	if($obj->Insert("categories","name='$name',status=$status")){
		//$msg="Insert Success";
		header("location:home.php?action=category");
	}
	else{
		$msg="Insert Fail";	
	}
}

if(isset($_REQUEST['add_article'])){
	extract($_REQUEST);
	
	if($obj->Insert("articles","title='$title',content='$content1', cat_id=$cat_id,status=$status")){
		//$msg="Insert Success";
		header("location:home.php?action=article");
	}
	else{
		$msg="Insert Fail";	
	}
}

if(isset($_REQUEST['update_menu'])){
	extract($_REQUEST);
	
	if($obj->Update("menus","name='$name',content='$content1',status=$status","menu_id=$menu_id")){
		//$msg="Insert Success";
		header("location:home.php?action=menu");
	}
	else{
		$msg="Update Fail";	
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Free CSS template by ChocoTemplates.com</title>
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <script src="ckeditor/ckeditor.js" type="text/javascript"></script>
</head>
<body>

	
	<!-- Header -->
	<div id="header">
		<div class="shell">
			
			<div id="head">
				<h1><a href="#">Admin Skin</a></h1>
				<div class="right">
					<p>
						Welcome <a href="#"><strong><?php echo $_SESSION['name']; ?></strong></a> | 
						<a href="#">Help</a> |
						<a href="#">Profile Settings</a> |
						<a href="home.php?logout=logout">Logout</a>
					</p>
				</div>
			</div>
			
			<!-- Navigation -->
			<div id="navigation">
				<ul>
				    <li><a href="home.php"><span>Dashboard</span></a></li>
				    <li><a href="home.php?action=menu"><span>Manage Menus</span></a></li>
				    <li><a href="home.php?action=user"><span>User Management</span></a></li>
				    <li><a href="home.php?action=article"><span>Manage Article</span></a></li>
				    <li><a href="home.php?action=category"><span>Manage Category</span></a></li>
				   
				</ul>
			</div>
			<!-- End Navigation -->
			
		</div>
	</div>
	<!-- End Header -->
	
	
	
	<!-- Content -->
	<div id="content" class="shell">
		
		<?php
		switch(@$_REQUEST['action']){
			case 'menu':
			echo "<h2>Manage Menus</h2>";
				if($obj->getAll("menus","*")!=false){
					$all_menus= $obj->getAll("menus","menu_id,name,status");
					?>
                    	<table border="1" width="500">
                        	<tr>
                            	<th>Menu Id</th>
                                <th>Name</th>
                                <th> Status</th>
                                <th> Action</th>
                            </tr>
                            <?php
								foreach($all_menus as $menu){
									extract($menu);
									echo "<tr>";
										echo "<td align=\"left\">$menu_id</td>";
										echo "<td align=\"left\">$name</td>";
										echo $status==1?"<td align=\"left\">Publish</td>":"<td align=\"left\">Unpublish</td>";
										echo "<td><a href=\"home.php?action=edit_menu&menu_id=$menu_id\">Edit</a></td>";
										
									
									echo "</tr>";
									
									
								}
								
							?>	
                            
                          
                            <tr>
                          		<td colspan="5"><a href="home.php?action=add_menu">Add New Menu</a></td>
                            </tr>
                        
                        </table>
                    
                    <?php
					
					
				}
				else{
					echo "No Menu Available";	
				}
			break;
			case 'user':
			echo "<h2>Manage User</h2>";
			break;
			case 'article':
			echo "<h2>Manage Article</h2>";
			
			if($obj->getAll("articles","*")!=false){
					$all_articles= $obj->getAll("articles","art_id,cat_id,title,status");
					?>
                    	<table border="1" width="500">
                        	<tr>
                            	<th>Article Id</th>
                                <th>Title</th>
                                <th>Category Name</th>
                                <th> Status</th>
                                <th> Action</th>
                            </tr>
                            <?php
								foreach($all_articles as $article){
									extract($article);
									echo "<tr>";
										echo "<td align=\"left\">$art_id</td>";
										echo "<td align=\"left\">$title</td>";
										$category=$obj->getMenuById("categories","name","cat_id=$cat_id");
										echo "<td align=\"left\">$category[name]</td>";
										echo $status==1?"<td align=\"left\">Publish</td>":"<td align=\"left\">Unpublish</td>";
										echo "<td><a href=\"home.php?action=edit_article&art_id=$art_id\">Edit</a></td>";
										
									
									echo "</tr>";
									
									
								}
								
							?>	
                            
                          
                            <tr>
                          		<td colspan="5"><a href="home.php?action=add_article">Add New Article</a></td>
                            </tr>
                        
                        </table>
                    
                    <?php
					
					
				}
				else{
					echo "No Article Available";	
					?>
                    <a href="home.php?action=add_article">Add New Article</a>
                    <?php
				}
			
			break;
			case 'category':
			echo "<h2>Manage Categories</h2>";
			
				if($obj->getAll("categories","*")!=false){
					$all_category= $obj->getAll("categories","cat_id,name,status");
					?>
                    	<table border="1" width="500">
                        	<tr>
                            	<th>Category Id</th>
                                <th>Name</th>
                                <th> Status</th>
                                <th> Action</th>
                            </tr>
                            <?php
								foreach($all_category as $category){
									extract($category);
									echo "<tr>";
										echo "<td align=\"left\">$cat_id</td>";
										echo "<td align=\"left\">$name</td>";
										echo $status==1?"<td align=\"left\">Publish</td>":"<td align=\"left\">Unpublish</td>";
										echo "<td><a href=\"home.php?action=edit_category&cat_id=$cat_id\">Edit</a></td>";
										
									
									echo "</tr>";
									
									
								}
								
							?>	
                            
                          
                            <tr>
                          		<td colspan="5"><a href="home.php?action=add_category">Add New Category</a></td>
                            </tr>
                        
                        </table>
                    
                    <?php
					
					
				}
				else{
					echo "No Category Available";	
					?>
                    <a href="home.php?action=add_category">Add New Category</a>
                    <?php
				}
			break;
			case 'add_menu':
			echo "<h2>Add New Menu</h2>";
			?>
            <form action="home.php" method="post">
            	<table width="800" border="1">
  <tbody>
    <tr>
      <th scope="row">Menu Name</th>
      <td><input type="text" name="name" size="100" /></td>
    </tr>
    <tr>
      <th scope="row">Content</th>
      <td><textarea name="content1" id="content"  rows="5" cols="100"></textarea>
      <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'content1' );
            </script>
      </td>
    </tr>
    <tr>
      <th scope="row">Status</th>
      <td><input type="radio" name="status" value="1"  />
      Publish &nbsp;&nbsp;
      <input type="radio" name="status" value="0" checked="checked" />Unpublish
      
      </td>
    </tr>
    <tr>
      <th scope="row" colspan="4">
      <input type="hidden" name="add_menu" value="yes" />
     
      <input type="submit" name="submit" value="Save" /></th>
    
    </tr>
  
  </tbody>
</table>

        </form>    
            <?php
			
			case 'add_category':
			echo "<h2>Add New category</h2>";
			?>
            <form action="home.php" method="post">
            	<table width="800" border="1">
  <tbody>
    <tr>
      <th scope="row">Category Name</th>
      <td><input type="text" name="name" size="100" /></td>
    </tr>
    
    <tr>
      <th scope="row">Status</th>
      <td><input type="radio" name="status" value="1"  />
      Publish &nbsp;&nbsp;
      <input type="radio" name="status" value="0" checked="checked" />Unpublish
      
      </td>
    </tr>
    <tr>
      <th scope="row" colspan="4">
      <input type="hidden" name="add_category" value="yes" />
     
      <input type="submit" name="submit" value="Save" /></th>
    
    </tr>
  
  </tbody>
</table>

        </form>    
            <?php
			break;
			case 'add_article':
			echo "<h2>Add New Article</h2>";
			?>
            <form action="home.php" method="post">
            	<table width="800" border="1">
  <tbody>
    <tr>
      <th scope="row">Article Title</th>
      <td><input type="text" name="title" size="100" /></td>
    </tr>
     <tr>
      <th scope="row">Content</th>
      <td><textarea name="content1" id="content"  rows="5" cols="100"></textarea>
      <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'content1' );
            </script>
      </td>
    </tr>
      <tr>
      <th scope="row">Category Name</th>
      <td>
      		<select name="cat_id">
            	<?php
					$categories=$obj->getAll("categories","*");
					foreach($categories as $category){
						extract($category);
				?>
            <option value="<?php echo $cat_id; ?>"><?php echo $name; ?></option>
            
            <?php
					}
					?>
            </select>
      </td>
    </tr>
    <tr>
      <th scope="row">Status</th>
      <td><input type="radio" name="status" value="1"  />
      Publish &nbsp;&nbsp;
      <input type="radio" name="status" value="0" checked="checked" />Unpublish
      
      </td>
    </tr>
    <tr>
      <th scope="row" colspan="4">
      <input type="hidden" name="add_article" value="yes" />
     
      <input type="submit" name="submit" value="Save" /></th>
    
    </tr>
  
  </tbody>
</table>

        </form>    
            <?php
			break;
		case 'edit_article':
			
			$art_id=$_REQUEST['art_id'];
			extract($obj->getMenuById("articles","*","art_id=$art_id"));
			echo "<h2>Edit Article</h2>";
			?>
            <form action="home.php" method="post">
            	<table width="800" border="1">
  <tbody>
    <tr>
      <th scope="row">Title</th>
      <td><input type="text" name="name" value="<?php echo isset($title)?$title:''; ?>" size="100" /></td>
    </tr>
    <tr>
      <th scope="row">Content</th>
      <td><textarea name="content1" id="content"  rows="5" cols="100"><?php echo isset($content)?$content:''; ?></textarea>
      <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'content1' );
            </script>
      </td>
    </tr>
    
          <tr>
      <th scope="row">Category Name</th>
      <td>
      		<select name="cat_id">
            	<?php
					$categories=$obj->getAll("categories","*");
					foreach($categories as $category){
						
				?>
            <option <?php echo ($cat_id==$category['cat_id'])?'selected':''?> value="<?php echo $category['cat_id']; ?>"><?php echo $category['name']; ?></option>
            
            <?php
					}
					?>
            </select>
      </td>
    </tr>
    <tr>
      <th scope="row">Status</th>
      <td><input type="radio" name="status" value="1" <?php echo $status==1?'checked="checked"':''?> />
      Publish &nbsp;&nbsp;
      <input type="radio" name="status" value="0" <?php echo $status==0?'checked="checked"':''?> />Unpublish
      
      </td>
    </tr>
    <tr>
      <th scope="row" colspan="4">
      <input type="hidden" name="update_menu" value="yes" />
       <input type="hidden" name="menu_id" value="<?php echo $menu_id; ?>" />
      <input type="submit" name="submit" value="Save" /></th>
    
    </tr>
  
  </tbody>
</table>

        </form>    
            <?php
			break;
		
		
			case 'edit_menu':
			
			$menu_id=$_REQUEST['menu_id'];
			extract($obj->getMenuById("menus","*","menu_id=$menu_id"));
			echo "<h2>Edit Menu</h2>";
			?>
            <form action="home.php" method="post">
            	<table width="800" border="1">
  <tbody>
    <tr>
      <th scope="row">Menu Name</th>
      <td><input type="text" name="name" value="<?php echo isset($name)?$name:''; ?>" size="100" /></td>
    </tr>
    <tr>
      <th scope="row">Content</th>
      <td><textarea name="content1" id="content"  rows="5" cols="100"><?php echo isset($content)?$content:''; ?>"</textarea>
      <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'content1' );
            </script>
      </td>
    </tr>
    <tr>
      <th scope="row">Status</th>
      <td><input type="radio" name="status" value="1" <?php echo $status==1?'checked="checked"':''?> />
      Publish &nbsp;&nbsp;
      <input type="radio" name="status" value="0" <?php echo $status==0?'checked="checked"':''?> />Unpublish
      
      </td>
    </tr>
    <tr>
      <th scope="row" colspan="4">
      <input type="hidden" name="update_menu" value="yes" />
       <input type="hidden" name="menu_id" value="<?php echo $menu_id; ?>" />
      <input type="submit" name="submit" value="Save" /></th>
    
    </tr>
  
  </tbody>
</table>

        </form>    
            <?php
			break;
			default:
			echo "<h2>Admin DashBoard</h2>";
		
			
		}
		?>
	
	
	<!-- End Content -->
</div>

<!-- Footer -->
<div id="footer">
	<p>&copy; Sitename.com. Design by <a href="http://chocotemplates.com">ChocoTemplates.com</a></p>
</div>
<!-- End Footer -->
</body>
</html>
