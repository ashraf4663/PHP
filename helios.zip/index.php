<?php
include("header.php");
?>
			<!-- Main -->
				<div class="wrapper style1">

					<div class="container">
						<div class="row 200%">
							
							<?php
							include("content.php");
							include("sidebar.php");
							?>
						</div>
						<hr />
						
					</div>

				</div>

			<?php
				include("footer.php");
			?>